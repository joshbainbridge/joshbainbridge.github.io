#!/usr/bin/python

import sys
import subprocess
import prman

def loadObject(filename=None):
  num_verts = 0
  verts = []
  textures = []
  norms = []
  verts_out = []
  textures_out = []
  norms_out = []

  # The following section is modified from :-
  # Nandor (January 13, 2011). Loading Wavefront OBJ files with Python [online]. [Accessed 2015]
  # Available from: <http://www.nandnor.net/?p=86>.
  for line in open(filename, "r"):
    vals = line.split()
    if len(vals) != 0:
      if vals[0] == "v":
        v = map(float, vals[1:4])
        verts.append(v)
      if vals[0] == "vt":
        t = map(float, vals[1:3])
        textures.append(t)
      if vals[0] == "vn":
        n = map(float, vals[1:4])
        norms.append(n)
      if vals[0] == "f":
        for f in vals[1:]:
          w = f.split("/")
          verts_out.extend(list(verts[int(w[0])-1]))
          textures_out.extend(list(textures[int(w[1])-1]))
          norms_out.extend(list(norms[int(w[2])-1]))
          num_verts += 1
  # end of Citation

  if num_verts % 3 != 0:
    print("Error: number of vertices is not divisionable by a value of three.")
    return 1

  num_faces = num_verts / 3

  return verts_out, norms_out, textures_out, num_faces

def main(argv=None):
  if argv is None:
    argv = sys.argv

  #Check argument input
  if len(argv) != 2:
    print("Error: please give a single .obj file to render.")
    return 2
  else:
    ect = argv[1].split(".")[-1];
    if ect != "obj":
      print("Error: please give an .obj file to render.")
      return 2

  #Compile shaders
  if subprocess.call(["shader", "dielectricShader.sl"]) != 0:
    print("Error: shader did not compile.")
    return 1

  if subprocess.call(["shader", "diffuseShader.sl"]) != 0:
    print("Error: shader did not compile.")
    return 1
    
  if subprocess.call(["shader", "layeredShader.sl"]) != 0:
    print("Error: shader did not compile.")
    return 1

  #Load in object data
  object_data = loadObject(argv[1])
  pointsPolyNvertices = []
  for i in range(object_data[3]):
    pointsPolyNvertices.append(3)
  pointsPolyVertices = range(object_data[3] * 3)

  #Load in backdrop data
  backdrop_data = loadObject("./backdrop_data.obj")
  pointsPolyNvertices_bd = []
  for i in range(backdrop_data[3]):
    pointsPolyNvertices_bd.append(3)
  pointsPolyVertices_bd = range(backdrop_data[3] * 3)

  #Create instance of the interface
  ri = prman.Ri()

  #Ri starts here
  ri.Begin("__render")

  #Options (Note: Set maxsamples back to 256 and enable statistics)
  ri.Display("output.exr", "it", "rgba", {"exposure":[1, 1]})
  ri.Hider("raytrace", {"string integrationmode":["path"], "int minsamples":[1], "int maxsamples":[256], "int incremental":[1], "float[4] aperture":[5, 0, 0, 0]})
  ri.Attribute("visibility", {"diffuse":1, "specular":1, "transmission":1})
  ri.Option("statistics", {"int endofframe":[1]})

  resolution = 1.0 / 3
  ri.Format(int(1280 * resolution), int(720 * resolution), 1)
  ri.Projection(ri.PERSPECTIVE, {"fov":[20]})
  ri.DepthOfField(32, 55.0, 37.5)

  #Camera transformations
  ri.Translate(0, 0, 40)
  ri.Rotate(-12, 1, 0, 0)
  ri.Rotate(0, 0, 1, 0)
  ri.Translate(0, -5, 0)
  ri.Scale(1, 1, -1)

  #Scene description start
  ri.WorldBegin()
  
  #Light one
  ri.AttributeBegin()

  ri.Translate(-22, 8.5, -2)
  ri.Rotate(90, 0, 1, 0)
  ri.Scale(10, 15, 1)

  ri.LightSource("plausibleArealight", {ri.HANDLEID:"light_source_01", "float intensity":8, "color lightcolor":[1, 0.87, 0.79], "float maxSamples":64})

  ri.AttributeEnd()

  #Light two
  ri.AttributeBegin()

  ri.Translate(22, 8.5, -2)
  ri.Rotate(-90, 0, 1, 0)
  ri.Scale(10, 15, 1)

  ri.LightSource("plausibleArealight", {ri.HANDLEID:"light_source_02", "float intensity":1.8, "color lightcolor":[0.9, 0.91, 1], "float maxSamples":64})

  ri.AttributeEnd()

  #Environment light
  ri.AttributeBegin()

  ri.Translate(0, 0, 0)
  ri.Rotate(0, 0, 1, 0)
  ri.Scale(1, 1, 1)

  ri.LightSource("plausibleEnvlight", {ri.HANDLEID:"light_source_env", "float intensity":0.8, "float nsamples":8, "string mapname":"desert.env"})

  ri.AttributeEnd()

  #Make sure lights are turned on
  ri.Illuminate("light_source_01", 1)
  ri.Illuminate("light_source_02", 1)
  ri.Illuminate("light_source_env", 1)

  #Draw cup geometry
  ri.AttributeBegin()
  ri.Shader("dielectricShader", "ceramic_layer", {"string diffuse_map":"colour.tex", "float specular_intensity":0.75, "float ior":1.5})
  ri.Shader("diffuseShader", "clay_layer", {"color diffuse_color":[0.823, 0.505, 0.449], "float diffuse_intensity":0.3, "roughness":0.5})
  ri.Shader("layeredShader", "base_layer", {"string shader_one":"ceramic_layer", "string shader_two":"clay_layer", "string blend_map":"clay_mask.tex"})
  ri.Shader("diffuseShader", "dirt_layer", {"color diffuse_color":[0.723, 0.715, 0.674], "float diffuse_intensity":0.7, "roughness":0.5})
  ri.Shader("layeredShader", "old_layer", {"string shader_one":"base_layer", "string shader_two":"dirt_layer", "string blend_map":"dirt_mask.tex", "float noise_blend":0, "float bump_value":-0.01})
  ri.Shader("diffuseShader", "coffee_layer", {"color diffuse_color":[0.723, 0.505, 0.449], "float diffuse_intensity":0.2, "roughness":0.3})
  ri.Surface("layeredShader", {"string shader_one":"old_layer", "string shader_two":"coffee_layer", "string blend_map":"coffee_mask.tex", "float noise_blend":0, "float bump_value":-0.01})
  ri.PointsPolygons(pointsPolyNvertices, pointsPolyVertices, {ri.P:object_data[0], ri.N:object_data[1], ri.ST:object_data[2]})
  ri.AttributeEnd()

  #Draw backdrop geometry
  ri.AttributeBegin()
  ri.Surface("plausibleMatte", {"string surfaceMap":"floor_pattern.tex"})
  ri.PointsPolygons(pointsPolyNvertices_bd, pointsPolyVertices_bd, {ri.P:backdrop_data[0], ri.N:backdrop_data[1], ri.ST:backdrop_data[2]})
  ri.AttributeEnd()

  ri.WorldEnd()
  #Scene description end

  ri.End()
  #Ri ends here

  print("Process complete.")
  return 0

if __name__ == '__main__':
  sys.exit(main())